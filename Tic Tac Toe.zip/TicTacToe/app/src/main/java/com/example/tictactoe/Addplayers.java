package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Addplayers extends AppCompatActivity {
    public static final String PLAYER_ONE_KEY = "playerOne";
    public static final String PLAYER_TWO_KEY = "playerTwo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addplayers);

        final EditText playerOne = findViewById(R.id.playerOneName);
        final EditText playerTwo = findViewById(R.id.playerTwoName);
        final Button startGameBtn = findViewById(R.id.startgamebtn);

        startGameBtn.setOnClickListener(view -> {
            final String getPlayerOneName = playerOne.getText().toString().trim();
            final String getPlayerTwoName = playerTwo.getText().toString().trim();

            if (getPlayerOneName.isEmpty() || getPlayerTwoName.isEmpty()) {
                Toast.makeText(Addplayers.this, "Please enter player names", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(Addplayers.this, MainActivity.class);
                intent.putExtra(PLAYER_ONE_KEY, getPlayerOneName);
                intent.putExtra(PLAYER_TWO_KEY, getPlayerTwoName);

                try {
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(Addplayers.this, "Error starting the game", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
